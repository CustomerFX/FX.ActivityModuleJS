/*
	Customer FX Activity Module
	See license and usage information at https://github.com/CustomerFX/FX.ActivityModule.JS

	Copyright (c) 2017 Customer FX Corporation
	http://customerfx.com
*/

define([
    'FXActivity/ActivityModule'
], function () {
    // load & initialize
});
