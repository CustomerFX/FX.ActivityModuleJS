/*
	Customer FX Activity Module
	See license and usage information at https://github.com/CustomerFX/FX.ActivityModule.JS

	Copyright (c) 2017 Customer FX Corporation
	http://customerfx.com
*/

define([
    'dojo/_base/lang'
],
function(
    lang
) {

    return {

        configurations: [
		
            // Add custom configurations here 
			// See https://github.com/CustomerFX/FX.ActivityModule.JS/blob/master/README.md
			
        ]

    };

});
